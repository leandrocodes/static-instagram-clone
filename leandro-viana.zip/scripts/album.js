const picList = [
  'assets/images/post1.jpg',
  'assets/images/post2.jpg',
  'assets/images/post3.jpg',
  'assets/images/post4.jpg',
  'assets/images/post5.jpg',
  'assets/images/post6.jpg',
  'assets/images/post7.jpg',
  'assets/images/post8.jpg',
  'assets/images/post9.jpg',
]